'use strict';

goog.provide('Blockly.Blocks.KS_EasyPulg');

goog.require('Blockly.Blocks');

//////////////////颜色/////////////////////
Blockly.Blocks.KS_EasyPulg.HUE = 120;

/////////////////模拟输出//////////////////////
Blockly.Blocks.ks_a_Write = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_KS_analog);
    //.appendField(new Blockly.FieldImage("../../media/KS0077/ks77_led3.png", 43, 32));
    this.appendValueInput("PIN", Number)
    .appendField(Blockly.MIXLY_PIN)
    .setAlign(Blockly.ALIGN_RIGHT)
    .setCheck(Number);
    this.appendValueInput("num", Number)
    .appendField(Blockly.MIXLY_KS_PWM)
    .setAlign(Blockly.ALIGN_RIGHT)
    .setCheck(Number);
    
    //.appendField(new Blockly.FieldDropdown([[Blockly.KS_ON, "HIGH"], [Blockly.KS_OFF, "LOW"]]), "STAT");
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setInputsInline(true);
  }
};

////////////////////LED//////////////////////////
Blockly.Blocks.ks_ledw = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_KS_LEDW)
    .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_ledw.png", 43, 32));
    this.appendValueInput("PIN", Number)
    .appendField(Blockly.MIXLY_PIN)
    .setCheck(Number);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_STAT)
    .appendField(new Blockly.FieldDropdown([[Blockly.KS_ON, "HIGH"], [Blockly.KS_OFF, "LOW"]]), "STAT");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
  }
};

Blockly.Blocks.ks_ledr = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_KS_LEDR)
    .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_ledr.png", 43, 32));
    this.appendValueInput("PIN", Number)
    .appendField(Blockly.MIXLY_PIN)
    .setCheck(Number);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_STAT)
    .appendField(new Blockly.FieldDropdown([[Blockly.KS_ON, "HIGH"], [Blockly.KS_OFF, "LOW"]]), "STAT");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
  }
};
Blockly.Blocks.ks_ledg = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_KS_LEDG)
    .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_ledg.png", 43, 32));
    this.appendValueInput("PIN", Number)
    .appendField(Blockly.MIXLY_PIN)
    .setCheck(Number);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_STAT)
    .appendField(new Blockly.FieldDropdown([[Blockly.KS_ON, "HIGH"], [Blockly.KS_OFF, "LOW"]]), "STAT");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
  }
};
Blockly.Blocks.ks_ledb = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_KS_LEDB)
    .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_ledb.png", 43, 32));
    this.appendValueInput("PIN", Number)
    .appendField(Blockly.MIXLY_PIN)
    .setCheck(Number);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_STAT)
    .appendField(new Blockly.FieldDropdown([[Blockly.KS_ON, "HIGH"], [Blockly.KS_OFF, "LOW"]]), "STAT");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
  }
};
Blockly.Blocks.ks_ledy = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_KS_LEDY)
    .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_ledy.png", 43, 32));
    this.appendValueInput("PIN", Number)
    .appendField(Blockly.MIXLY_PIN)
    .setCheck(Number);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_STAT)
    .appendField(new Blockly.FieldDropdown([[Blockly.KS_ON, "HIGH"], [Blockly.KS_OFF, "LOW"]]), "STAT");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
  }
};



/////////////////有源蜂鸣器//////////////////////
Blockly.Blocks.ks_y_buzzer = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_KS_BUZZER1)
    .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_buzzer.png", 39, 32));    
    this.appendValueInput("PIN", Number)
    .appendField(Blockly.MIXLY_PIN)
    .setCheck(Number);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_STAT)
    .appendField(new Blockly.FieldDropdown([[Blockly.KS_ON, "HIGH"], [Blockly.KS_OFF, "LOW"]]), "STAT");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
  }
};

/////////////////蜂鸣器//////////////////////
Blockly.Blocks.ks_w_buzzer1 = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_KS_BUZZER2)
    .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_pbuzzer.png", 39, 32));    
    this.appendValueInput("PIN", Number)
    .appendField(Blockly.MIXLY_PIN)
    .setCheck(Number);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_STAT)
    .appendField(new Blockly.FieldDropdown([[Blockly.KS_ON, "HIGH"], [Blockly.KS_OFF, "LOW"]]), "STAT");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
  }
};
Blockly.Blocks.ks_w_buzzer2={
  init:function(){
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_KS_BUZZER2)
    .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_pbuzzer.png", 39, 32));    
    this.appendValueInput("PIN", Number)
    .appendField(Blockly.MIXLY_PIN)
    .setCheck(Number);
    this.appendValueInput('FREQUENCY')
    .setCheck(Number)
        //.setAlign(Blockly.ALIGN_RIGHT)
        .appendField(Blockly.MIXLY_FREQUENCY);
        this.setInputsInline(true);
        this.setPreviousStatement(true);
        this.setNextStatement(true);
      }
    };
    Blockly.Blocks.ks_w_buzzer3={
      init:function(){
        this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
        this.appendDummyInput("")
        .appendField(Blockly.MIXLY_KS_BUZZER2)
        .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_pbuzzer.png", 39, 32));    
        this.appendValueInput("PIN", Number)
        .appendField(Blockly.MIXLY_PIN)
        .setCheck(Number);
        this.appendValueInput('FREQUENCY')
        .setCheck(Number)
        //.setAlign(Blockly.ALIGN_RIGHT)
        .appendField(Blockly.MIXLY_FREQUENCY);
        this.appendValueInput('DURATION')
        .setCheck(Number)
        //.setAlign(Blockly.ALIGN_RIGHT)
        .appendField(Blockly.MIXLY_DURATION);
        this.setInputsInline(true);
        this.setPreviousStatement(true);
        this.setNextStatement(true);
      }
    };

    //////////////////蜂鸣器//////////////////
var TONE_NOTES=[["NOTE_C3", "131"],["NOTE_D3", "147"],["NOTE_E3", "165"],["NOTE_F3", "175"],["NOTE_G3", "196"],["NOTE_A3", "220"],["NOTE_B3", "247"],
           ["NOTE_C4", "262"],["NOTE_D4", "294"],["NOTE_E4", "330"],["NOTE_F4", "349"],["NOTE_G4", "392"],["NOTE_A4", "440"],["NOTE_B4", "494"],
           ["NOTE_C5", "532"],["NOTE_D5", "587"],["NOTE_E5", "659"],["NOTE_F5", "698"],["NOTE_G5", "784"],["NOTE_A5", "880"],["NOTE_B5", "988"]];


Blockly.Blocks.tone01 = {
   init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
        .appendField(new Blockly.FieldDropdown(TONE_NOTES), 'STAT');
    this.setOutput(true, Number);
  }
};

Blockly.Blocks.buzzer={
init:function(){
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField(Blockly.Desk_buzzer)
    .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_pbuzzer.png", 39, 32));   
    this.appendValueInput("PIN", Number)
        .appendField(Blockly.MIXLY_PIN)
        .setCheck(Number);
    this.appendValueInput('FREQUENCY')
        .setCheck(Number)
        //.setAlign(Blockly.ALIGN_RIGHT)
        .appendField(Blockly.Desk_fre);

    this.appendValueInput('DURATION')
        .setCheck(Number)
        //.setAlign(Blockly.ALIGN_RIGHT)
        .appendField(Blockly.MIXLY_DURATION);
    this.appendDummyInput("")
        .appendField(Blockly.MIXLY_DELAY_MS);
    
    this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setTooltip(Blockly.MIXLY_TOOLTIP_BLOCKGROUP_TONE);
  }
};

Blockly.Blocks.controls_tone2={
init:function(){
    this.setColour(Blockly.Blocks.actuator.HUE);
    this.appendValueInput("PIN", Number)
        .appendField(Blockly.MIXLY_TONE_PIN)
        .setCheck(Number);
    this.appendValueInput('FREQUENCY')
        .setCheck(Number)
        //.setAlign(Blockly.ALIGN_RIGHT)
        .appendField(Blockly.KS_FREQUENCY);
    this.appendValueInput('DURATION')
        .setCheck(Number)
        //.setAlign(Blockly.ALIGN_RIGHT)
        .appendField(Blockly.MIXLY_DURATION);
    this.appendDummyInput("")
        .appendField(Blockly.MIXLY_DELAY_MS);
    this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setTooltip(Blockly.MIXLY_TOOLTIP_BLOCKGROUP_TONE2);
  }
};

///////////music////////////////////
Blockly.Blocks.music = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
        .appendField(Blockly.Desk_play_music)
        .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_pbuzzer.png", 39, 32));
    this.appendValueInput("PIN", Number)
        .appendField(Blockly.MIXLY_PIN)
        .setCheck(Number);   
    this.appendDummyInput("")
        //.appendField(new Blockly.FieldDropdown([["Birthday", "Birthday"],["City of Sky", "City of Sky"],["Ode to Joy", "Ode to Joy"]]), 'play');
        .appendField(new Blockly.FieldDropdown([[Blockly.Desk_Ode_to_joy, "Ode to Joy"],[Blockly.Desk_birthday, "Birthday"]]), 'play');
    
    this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setTooltip(Blockly.MIXLY_TOOLTIP_BLOCKGROUP_NOTONE);
  }
};

////////////////////关闭蜂鸣器////////////////////////
Blockly.Blocks.notone={
init:function(){
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
        .appendField(Blockly.Desk_notone)
        .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_pbuzzer.png", 39, 32));
    this.appendValueInput("PIN", Number)
        .appendField(Blockly.MIXLY_PIN)
        .setCheck(Number);   
    this.setInputsInline(true);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    //this.setTooltip(Blockly.MIXLY_TOOLTIP_BLOCKGROUP_NOTONE);
  }
};


///////////////////////继电器////////////////////////////
Blockly.Blocks.ks_relay = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_KS_RELAY)
    .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_relay.png", 43, 32));
    this.appendValueInput("PIN", Number)
    .appendField(Blockly.MIXLY_PIN)
    .setCheck(Number);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_STAT)
    .appendField(new Blockly.FieldDropdown([[Blockly.KS_ON, "HIGH"], [Blockly.KS_OFF, "LOW"]]), "STAT");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
  }
};

////////////////////////电机///////////////////////////////////
Blockly.Blocks.ks_motor = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_KS_MOTOR)
    .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_dianji.png", 43, 32));
    this.appendValueInput("PIN1", Number)
    .appendField(Blockly.MIXLY_PIN)
    .setCheck(Number);
    this.appendDummyInput("")
    .appendField('INA')
    .appendField(new Blockly.FieldDropdown([[Blockly.KS_ON, "HIGH"], [Blockly.KS_OFF, "LOW"]]), "STAT1");
    this.appendValueInput("PIN2", Number)
    .appendField(Blockly.MIXLY_PIN)
    .setCheck(Number);
    this.appendDummyInput("")
    .appendField('INB')
    .appendField(new Blockly.FieldDropdown([[Blockly.KS_ON, "HIGH"], [Blockly.KS_OFF, "LOW"]]), "STAT2");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
  }
};

///////////////////////////舵机///////////////////////////////////
Blockly.Blocks.ks_servo = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendValueInput("PIN", Number)
    .appendField(Blockly.MIXLY_KS_SERVO)
    .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_servo.png", 70, 32))
    .appendField(Blockly.MIXLY_PIN)
    .setCheck(Number);
    this.appendValueInput("angle", Number)
    .setCheck(Number)
    .setAlign(Blockly.ALIGN_RIGHT)
    .appendField(Blockly.MIXLY_DEGREE_0_180);
    this.appendValueInput("time", Number)
    .setCheck(Number)
    .setAlign(Blockly.ALIGN_RIGHT)
    .appendField(Blockly.MIXLY_DELAY+'('+Blockly.MIXLY_DELAY_MS+')');
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setTooltip(Blockly.MIXLY_TOOLTIP_BLOCKGROUP_SERVO_MOVE);
  }
};

Blockly.Blocks.ks_servo_r = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendValueInput("PIN", Number)
    .appendField(Blockly.MIXLY_KS_SERVO)
    .appendField(Blockly.MIXLY_PIN)
    .setCheck(Number);
    this.appendDummyInput("")
    .setAlign(Blockly.ALIGN_RIGHT)
    .appendField(Blockly.MIXLY_READ_DEGREES);
    this.setOutput(true, Number);
    this.setInputsInline(true);
    this.setTooltip(Blockly.MIXLY_TOOLTIP_BLOCKGROUP_SERVO_READ);
  }
};


/////////////////////数字传感器///////////////////////////////

///////////人体红外传感器////////////////////
Blockly.Blocks.ks_ir_g = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_KS_IR_G)
    .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_rentihongwai.png", 43, 32));
    this.appendValueInput("PIN", Number)
    .appendField(Blockly.MIXLY_PIN)
    .setCheck(Number);
    this.setOutput(true, Number);
    this.setInputsInline(true);
    this.setTooltip('');
  }
};

///////////火焰传感器////////////////////
Blockly.Blocks.ks_flame = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_KS_FLAME)
    .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_fire.png", 43, 32));
    this.appendValueInput("PIN", Number)
    .appendField(Blockly.MIXLY_PIN)
    .setCheck(Number);
    this.setOutput(true, Number);
    this.setInputsInline(true);
    this.setTooltip('');
  }
};

///////////霍尔传感器////////////////////
Blockly.Blocks.ks_hall = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_KS_HALL)
    .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_hall.png", 43, 32));
    this.appendValueInput("PIN", Number)
    .appendField(Blockly.MIXLY_PIN)
    .setCheck(Number);
    this.setOutput(true, Number);
    this.setInputsInline(true);
    this.setTooltip('');
  }
};

///////////碰撞传感器////////////////////
Blockly.Blocks.ks_crash = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_KS_KNOCK)
    .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_pengzhuang.png", 43, 32));
    this.appendValueInput("PIN", Number)
    .appendField(Blockly.MIXLY_PIN)
    .setCheck(Number);
    this.setOutput(true, Number);
    this.setInputsInline(true);
    this.setTooltip('');
  }
};

///////////按键传感器////////////////////
Blockly.Blocks.ks_button = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_KS_BUTTON)
    .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_button.png", 43, 32));
    this.appendValueInput("PIN", Number)
    .appendField(Blockly.MIXLY_PIN)
    .setCheck(Number);
    this.setOutput(true, Number);
    this.setInputsInline(true);
    this.setTooltip('');
  }
};

///////////电容触摸传感器////////////////////
Blockly.Blocks.ks_tuoch = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_KS_TUOCH)
    .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_touch.png", 43, 32));
    this.appendValueInput("PIN", Number)
    .appendField(Blockly.MIXLY_PIN)
    .setCheck(Number);
    this.setOutput(true, Number);
    this.setInputsInline(true);
    this.setTooltip('');
  }
};

///////////敲击传感器////////////////////
Blockly.Blocks.ks_knock = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_KS_CRASH)
    .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_xiangwei.png", 43, 32));
    this.appendValueInput("PIN", Number)
    .appendField(Blockly.MIXLY_PIN)
    .setCheck(Number);
    this.setOutput(true, Number);
    this.setInputsInline(true);
    this.setTooltip('');
  }
};

///////////倾斜传感器////////////////////
Blockly.Blocks.ks_tilt = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_KS_TILT)
    .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_qingxie.png", 43, 32));
    this.appendValueInput("PIN", Number)
    .appendField(Blockly.MIXLY_PIN)
    .setCheck(Number);
    this.setOutput(true, Number);
    this.setInputsInline(true);
    this.setTooltip('');
  }
};

///////////振动传感器////////////////////
Blockly.Blocks.ks_shake = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_KS_SHAKE)
    .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_zhengdong.png", 43, 32));
    this.appendValueInput("PIN", Number)
    .appendField(Blockly.MIXLY_PIN)
    .setCheck(Number);
    this.setOutput(true, Number);
    this.setInputsInline(true);
    this.setTooltip('');
  }
};

///////////干簧管传感器////////////////////
Blockly.Blocks.ks_reed_s = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_KS_REED_S)
    .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_ghg.png", 43, 32));
    this.appendValueInput("PIN", Number)
    .appendField(Blockly.MIXLY_PIN)
    .setCheck(Number);
    this.setOutput(true, Number);
    this.setInputsInline(true);
    this.setTooltip('');
  }
};

///////////循迹传感器////////////////////
Blockly.Blocks.ks_track = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_KS_TRACK)
    .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_xunji.png", 43, 32));
    this.appendValueInput("PIN", Number)
    .appendField(Blockly.MIXLY_PIN)
    .setCheck(Number);
    this.setOutput(true, Number);
    this.setInputsInline(true);
    this.setTooltip('');
  }
};

///////////避障传感器////////////////////
Blockly.Blocks.ks_avoid = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_KS_AVOID)
    .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_hongwaibz.png", 43, 32));
    this.appendValueInput("PIN", Number)
    .appendField(Blockly.MIXLY_PIN)
    .setCheck(Number);
    this.setOutput(true, Number);
    this.setInputsInline(true);
    this.setTooltip('');
  }
};

///////////光折断传感器////////////////////
Blockly.Blocks.ks_light_b = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_KS_LIGHT_B)
    .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_photo.png", 43, 32));
    this.appendValueInput("PIN", Number)
    .appendField(Blockly.MIXLY_PIN)
    .setCheck(Number);
    this.setOutput(true, Number);
    this.setInputsInline(true);
    this.setTooltip('');
  }
};

///////////////////////////模拟传感器//////////////////////////
///////////模拟温度传感器///////////////
Blockly.Blocks.ks_analog_t = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_KS_ANALOG_T)
    .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_mnwd.png", 50, 40));
    this.appendValueInput("PIN", Number)
    .appendField(Blockly.MIXLY_PIN)
    .setCheck(Number);
    this.setInputsInline(true);
    this.setOutput(true, Number);
    this.setTooltip('');
  }
};

///////////声音传感器///////////////
Blockly.Blocks.ks_sound = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_KS_SOUND)
    .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_sound.png", 50, 40));
    this.appendValueInput("PIN", Number)
    .appendField(Blockly.MIXLY_PIN)
    .setCheck(Number);
    this.setInputsInline(true);
    this.setOutput(true, Number);
    this.setTooltip('');
  }
};

///////////光线传感器///////////////
Blockly.Blocks.ks_light = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_KS_LIGHT)
    .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_guangmin.png", 50, 40));
    this.appendValueInput("PIN", Number)
    .appendField(Blockly.MIXLY_PIN)
    .setCheck(Number);
    this.setInputsInline(true);
    this.setOutput(true, Number);
    this.setTooltip('');
  }
};

///////////水位传感器///////////////
Blockly.Blocks.ks_water = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_KS_WATER)
    .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_water.png", 50, 40));
    this.appendValueInput("PIN", Number)
    .appendField(Blockly.MIXLY_PIN)
    .setCheck(Number);
    this.setInputsInline(true);
    this.setOutput(true, Number);
    this.setTooltip('');
  }
};

///////////土壤传感器///////////////
Blockly.Blocks.ks_soil = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_KS_SOIL)
    .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_soil.png", 50, 40));
    this.appendValueInput("PIN", Number)
    .appendField(Blockly.MIXLY_PIN)
    .setCheck(Number);
    this.setInputsInline(true);
    this.setOutput(true, Number);
    this.setTooltip('');
  }
};

///////////电位器///////////////
Blockly.Blocks.ks_potentiometer = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_KS_POTENTIOMETER)
    .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_dianweiqi.png", 50, 40));
    this.appendValueInput("PIN", Number)
    .appendField(Blockly.MIXLY_PIN)
    .setCheck(Number);
    this.setInputsInline(true);
    this.setOutput(true, Number);
    this.setTooltip('');
  }
};

///////////LM35///////////////
Blockly.Blocks.ks_lm35 = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_KS_LM35)
    .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_lm35.png", 50, 40));
    this.appendValueInput("PIN", Number)
    .appendField(Blockly.MIXLY_PIN)
    .setCheck(Number);
    this.setInputsInline(true);
    this.setOutput(true, Number);
    this.setTooltip('');
  }
};

///////////滑动电位器///////////////
Blockly.Blocks.ks_slide_potentiometer = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_KS_SLIDE_POTENTIOMETER)
    .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_hddwq.png", 50, 40));
    this.appendValueInput("PIN", Number)
    .appendField(Blockly.MIXLY_PIN)
    .setCheck(Number);
    this.setInputsInline(true);
    this.setOutput(true, Number);
    this.setTooltip('');
  }
};

///////////TEMT6000环境光///////////////
Blockly.Blocks.ks_temt6000 = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_KS_TEMT6000)
    .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_temt6000.png", 50, 40));
    this.appendValueInput("PIN", Number)
    .appendField(Blockly.MIXLY_PIN)
    .setCheck(Number);
    this.setInputsInline(true);
    this.setOutput(true, Number);
    this.setTooltip('');
  }
};

///////////水蒸气传感器///////////////
Blockly.Blocks.ks_steam = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_KS_STEAM)
    .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_steam.png", 50, 40));
    this.appendValueInput("PIN", Number)
    .appendField(Blockly.MIXLY_PIN)
    .setCheck(Number);
    this.setInputsInline(true);
    this.setOutput(true, Number);
    this.setTooltip('');
  }
};

///////////薄膜压力传感器///////////////
Blockly.Blocks.ks_film_p = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_KS_FILM_P)
    .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_tptouch.png", 50, 40));
    this.appendValueInput("PIN", Number)
    .appendField(Blockly.MIXLY_PIN)
    .setCheck(Number);
    this.setInputsInline(true);
    this.setOutput(true, Number);
    this.setTooltip('');
  }
};


///////////摇杆传感器///////////////
var joystick = [
  ["x", "Lx"],
  ["y", "Ly"],
  ["z", "Lz"],
];
var joystick_pin = [
  ["A6", "A6"],
  ["A7", "A7"],
  ["2", "2"],
];

Blockly.Blocks.ks_joystick = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    //this.appendDummyInput("")
    this.appendDummyInput("").setAlign(Blockly.ALIGN_RIGHT).appendField(new Blockly.FieldDropdown(joystick), "joy");
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_KS_JOYSTICK)
    .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_joys.png", 50, 40));
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_PIN);
    this.appendDummyInput("").setAlign(Blockly.ALIGN_RIGHT).appendField(new Blockly.FieldDropdown(joystick_pin), "joy_pin");
    
    //.setCheck(Number);
    this.setInputsInline(true);
    this.setOutput(true, Number);
    this.setTooltip('');
  }
};

///////////摇杆传感器///////////////
/*var joystick = [
  ["x", "Lx"],
  ["y", "Ly"],
  ["z", "Lz"],
  //["Rx", "Rx"],
 // ["Ry", "Ry"], 
 // ["Rz", "Rz"]
];

Blockly.Blocks.ks_joystick = {
  init: function() {
    this.setColour(Blockly.Blocks.Keyes.HUE);
    this.appendDummyInput("").setAlign(Blockly.ALIGN_RIGHT).appendField(new Blockly.FieldDropdown(joystick), "joy");
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_KS_JOYSTICK)
    .appendField(new Blockly.FieldImage("../../media/KS0077/ks_joys.png", 50, 40));
    this.appendValueInput("PIN", Number)
    .appendField(Blockly.MIXLY_PIN)
    .setCheck(Number);
    
    this.setInputsInline(true);
    this.setOutput(true, Number);
    this.setTooltip('');
  }
};*/



///////////烟雾传感器///////////////
Blockly.Blocks.ks_smoke = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField("MQ-2")
    .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_gas.png", 50, 40));
    this.appendValueInput("PIN", Number)
    .appendField(Blockly.MIXLY_PIN)
    .setCheck(Number);
    this.setInputsInline(true);
    this.setOutput(true, Number);
    this.setTooltip('');
  }
};

///////////酒精传感器///////////////
Blockly.Blocks.ks_alcohol = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_KS_ALCOHOL)
    .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_alcohol.png", 50, 40));
    this.appendValueInput("PIN", Number)
    .appendField(Blockly.MIXLY_PIN)
    .setCheck(Number);
    this.setInputsInline(true);
    this.setOutput(true, Number);
    this.setTooltip('');
  }
};

///////////MQ135空气质量///////////////
Blockly.Blocks.ks_mq135 = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_KS_MQ135)
    .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_gas.png", 50, 40));
    this.appendValueInput("PIN", Number)
    .appendField(Blockly.MIXLY_PIN)
    .setCheck(Number);
    this.setInputsInline(true);
    this.setOutput(true, Number);
    this.setTooltip('');
  }
};

///////////18B20温度模块///////////////
Blockly.Blocks.ks_18b20 = {
    init: function () {
        var UNIT = [[Blockly.MIXLY_DS18B20_C, '0'], [Blockly.MIXLY_DS18B20_F, '1']];
        this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
        this.appendValueInput("PIN", Number)
            .appendField(Blockly.MIXLY_KS_18B20)
            .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_18B20.png", 50, 40))
            .setCheck(Number);
        this.appendDummyInput("")
            .appendField(Blockly.MIXLY_KS_RT)
            .appendField(new Blockly.FieldDropdown(UNIT), "UNIT");
        this.setOutput(true, Number);
    }
};

///////////////////////////////DHT11//////////////////////////////////
Blockly.Blocks.ks_dht11 = {
    init: function () {
        var WHAT = [[Blockly.MIXLY_DHT11_T, 'temperature'], [Blockly.MIXLY_DHT11_H, 'humidity']];
        this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
        this.appendValueInput("PIN", Number)
            .appendField(new Blockly.FieldDropdown([['DHT11', '11'], ['DHT21', '21'], ['DHT22', '22'], ['DHT33', '33'], ['DHT44', '44']]), 'TYPE')
            .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_dht11.png", 50, 40))
            .appendField(Blockly.MIXLY_PIN)
            .setCheck(Number);
        this.appendDummyInput("")
            .appendField(new Blockly.FieldDropdown(WHAT), "WHAT");
        this.setOutput(true, Number);
        var thisBlock = this;
        this.setTooltip(function () {
            var op = thisBlock.getFieldValue('WHAT');
            var TOOLTIPS = {
                'temperature': Blockly.MIXLY_TOOLTIP_BLOCKGROUP_GET_TEM,
                'humidity': Blockly.MIXLY_TOOLTIP_BLOCKGROUP_GET_HUM
            };
            return TOOLTIPS[op];
        });
    }
};

//////////BMP180高度计模块///////////////
Blockly.Blocks.ks_bmp180 = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_KS_BMP180)
    .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_bmp180.png", 50, 40));
    this.appendValueInput("PIN", Number)
    .appendField(Blockly.MIXLY_PIN)
    .setCheck(Number);
    this.setInputsInline(true);
    this.setOutput(true, Number);
    this.setTooltip('');
  }
};

/////////////////////////////////////////////
////////////////传感器////////////////////////
/////////////////////////////////////////////

///////////////超声波/////////////////////////
Blockly.Blocks.ks_sr01 = {
  init: function () {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_KS_SR01)
    .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_sr04.png", 50, 40));
    this.appendValueInput("PIN1", Number)
    .appendField('Trig#')
    .setCheck(Number);
    this.appendValueInput("PIN2", Number)
    .appendField('Echo#')
    .setCheck(Number);
    this.setInputsInline(true);
    this.setOutput(true, Number);
    this.setTooltip(Blockly.MIXLY_TOOLTIP_BLOCKGROUP_CHAOSHENGBO);
  }
};


var ADXL345_ZHOU = [
  [Blockly.MIXLY_ADXL345_X, "x"],
  [Blockly.MIXLY_ADXL345_Y, "y"],
  [Blockly.MIXLY_ADXL345_Z, "z"],
  [Blockly.MIXLY_ADXL345_XA, "xa"],
  [Blockly.MIXLY_ADXL345_YA, "ya"]
  //, [Blockly.MIXLY_ADXL345_ZA, "za"]
];
//传感器-重力感应块-获取数据
Blockly.Blocks.ks_adxl345 = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_KS_ADXL345)
    .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_adxl345.png", 50, 40));
    this.appendDummyInput("").setAlign(Blockly.ALIGN_RIGHT).appendField(new Blockly.FieldDropdown(ADXL345_ZHOU), "ADXL345_PIN");
    this.setInputsInline(true);
    this.setOutput(true);
   }
};

/////////////////////////////BMP180////////////////////////
var BMP180_TP = [
  [Blockly.MIXLY_KS_T, "T"],
  [Blockly.MIXLY_KS_QY, "P"],
  [Blockly.MIXLY_KS_H, "A"],
];
/////////////////////////////BMP180////////////////////////
Blockly.Blocks.ks_bmp180 = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_KS_BMP180)
    .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_bmp180.png", 50, 40));
    this.appendDummyInput("").setAlign(Blockly.ALIGN_RIGHT).appendField(new Blockly.FieldDropdown(BMP180_TP), "BMP180_PIN");
    this.setInputsInline(true);
    this.setOutput(true);
   }
};

//////////////////////////////////DS3231时钟。//////////////////////////////
//传感器-实时时钟块_设置时间
Blockly.Blocks.ks_ds3231 = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .setAlign(Blockly.ALIGN_RIGHT)
    .appendField(Blockly.MIXLY_KS_3231)
    .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_ds3231.png", 50, 40))
    .appendField(new Blockly.FieldTextInput('myTime'), 'RTCName');
    this.appendValueInput("dow").setCheck(Number).setAlign(Blockly.ALIGN_RIGHT).appendField(Blockly.MIXLY_KS_TEXT);
    this.appendValueInput("day").setCheck(Number).setAlign(Blockly.ALIGN_RIGHT).appendField(Blockly.MIXLY_KS_DAY);
    this.appendValueInput("month").setCheck(Number).setAlign(Blockly.ALIGN_RIGHT).appendField(Blockly.MIXLY_KS_MONTH);
    this.appendValueInput("year").setCheck(Number).setAlign(Blockly.ALIGN_RIGHT).appendField(Blockly.MIXLY_KS_YEAR);
    
    this.appendValueInput("hour").setCheck(Number).setAlign(Blockly.ALIGN_RIGHT).appendField(Blockly.MIXLY_KS_HOUR);
    this.appendValueInput("minute").setCheck(Number).setAlign(Blockly.ALIGN_RIGHT).appendField(Blockly.MIXLY_KS_MINUTE);
    this.appendValueInput("second").setCheck(Number).setAlign(Blockly.ALIGN_RIGHT).appendField(Blockly.MIXLY_KS_SECOND);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setInputsInline(false);
   }
};

////////////////////////////DS3231读取时间/////////////////////////////////
//传感器-实时时钟块_时间变量
var RTC_TIME_TYPE = [
  [Blockly.MIXLY_YEAR, "getYear"],
  [Blockly.MIXLY_MONTH, "getMonth"],
  [Blockly.MIXLY_DAY, "getDay"],
  [Blockly.MIXLY_HOUR, "getHour"],
  [Blockly.MIXLY_MINUTE, "getMinute"],
  [Blockly.MIXLY_SECOND, "getSecond"],
  [Blockly.MIXLY_WEEK, "getWeek"],
];


//传感器-实时时钟块_获取时间
Blockly.Blocks.ks_ds3231getTime = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("").setAlign(Blockly.ALIGN_RIGHT).appendField(Blockly.MIXLY_KS_GET);
    this.appendDummyInput("").setAlign(Blockly.ALIGN_RIGHT).appendField(new Blockly.FieldTextInput('myTime'), 'RTCName');
    this.appendDummyInput("").setAlign(Blockly.ALIGN_RIGHT).appendField(new Blockly.FieldDropdown(RTC_TIME_TYPE), "TIME_TYPE");
    this.setInputsInline(true);
    this.setOutput(true, Number);
  }
};


////////////////////////////////////////////////////
////////////////////////显示屏///////////////////////
////////////////////////////////////////////////////

//////////////////RGB灯////////////////////////////
Blockly.Blocks.ks_rgb = {
    init: function () {
        this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
        this.appendDummyInput("")
            .appendField(Blockly.MIXLY_KS_2812RGB)
            .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_rgb2812.png", 50, 40));
         this.appendValueInput("PIN", Number)
            .setCheck(Number)
            .setAlign(Blockly.ALIGN_RIGHT)
            .appendField(Blockly.MIXLY_PIN);
        this.appendValueInput("num01")
            .setCheck(Number)
            .setAlign(Blockly.ALIGN_RIGHT)
            .appendField(Blockly.MIXLY_KS_Count);
        this.appendValueInput("red")
            .setCheck(Number)
            .setAlign(Blockly.ALIGN_RIGHT)
            .appendField("R：");
        this.appendValueInput("green")
            .setCheck(Number)
            .setAlign(Blockly.ALIGN_RIGHT)
            .appendField("G：");
        this.appendValueInput("blue")
            .setCheck(Number)
            .setAlign(Blockly.ALIGN_RIGHT)
            .appendField("B：");
        this.setInputsInline(true);
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setTooltip('');
    }
};

/////////////////////TM1637数码管初始化////////////////////////////////////
Blockly.Blocks.ks_tm1637_init = {
    init: function () {
        this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
        this.appendDummyInput("")
            .appendField(Blockly.MIXLY_KS_TM1637)
            .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_shumaguan.png", 50, 40));
        this.appendValueInput("PIN1", Number)
            .setCheck(Number)
            .setAlign(Blockly.ALIGN_RIGHT)
            .appendField("#CLK:");
        this.appendValueInput("PIN2", Number)
            .setCheck(Number)
            .setAlign(Blockly.ALIGN_RIGHT)
            .appendField("#DIO:");
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setInputsInline(true);
        this.setTooltip(Blockly.MIXLY_4DIGITDISPLAY_TM1637_TIP);
        this.setHelpUrl('');
    }
};

//////////////////TM1637数码自定义显示////////////////////////////
Blockly.Blocks.ks_tm1637_dy = {
    init: function () {
        this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
        this.appendDummyInput("")
            .appendField(Blockly.MIXLY_KS_TM1637)
            .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_shumaguan.png", 50, 40));
  
        this.appendValueInput("num")
            .setCheck(Number)
            .setAlign(Blockly.ALIGN_RIGHT)
            .appendField(Blockly.MIXLY_KS_value);
   
        this.appendValueInput("weishu")
            .setCheck(Number)
            .setAlign(Blockly.ALIGN_RIGHT)
            .appendField(Blockly.MIXLY_KS_ws);
        this.appendValueInput("wei")
            .setCheck(Number)
            .setAlign(Blockly.ALIGN_RIGHT)
            .appendField(Blockly.MIXLY_KS_begin);
        this.setInputsInline(true);
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setTooltip('');
    }
};

//////////////////TM1637数码自定义显示是否填充////////////////////////////
Blockly.Blocks.ks_tm1637_tc = {
    init: function () {
        this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
        this.appendDummyInput("")
            .appendField(Blockly.MIXLY_KS_TM1637)
            .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_shumaguan.png", 50, 40));
  
        this.appendValueInput("num")
            .setCheck(Number)
            .setAlign(Blockly.ALIGN_RIGHT)
            .appendField(Blockly.MIXLY_KS_value);
   
        this.appendValueInput('0and1')
            .setCheck([Number,Boolean])
            .appendField(Blockly.MIXLY_KS_fill0);
        this.setInputsInline(true);
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setTooltip('');
    }
};

//////////////////TM1637数码管亮度////////////////////////////
Blockly.Blocks.ks_tm1637_ld = {
    init: function () {
        this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
        this.appendDummyInput("")
            .appendField(Blockly.MIXLY_KS_TM1637)
            .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_shumaguan.png", 50, 40));
  
        this.appendValueInput("num")
            .setCheck(Number)
            .setAlign(Blockly.ALIGN_RIGHT)
            .appendField(Blockly.MIXLY_KS_light);
   
        this.setInputsInline(true);
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setTooltip('');
    }
};

//////////////////TM1637数码管是否隐藏////////////////////////////
Blockly.Blocks.ks_tm1637_yc = {
    init: function () {
        this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
        this.appendDummyInput("")
            .appendField(Blockly.MIXLY_KS_TM1637)
            .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_shumaguan.png", 50, 40));
  
        this.appendValueInput('BOOL')
            .setCheck([Number,Boolean])
            .appendField(Blockly.MIXLY_KS_XY);
   
        this.setInputsInline(true);
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setTooltip('');
    }
};

//////////////////TM1637数码管是否显示冒号////////////////////////////
Blockly.Blocks.ks_tm1637_mh = {
    init: function () {
        this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
        this.appendDummyInput("")
            .appendField(Blockly.MIXLY_KS_TM1637)
            .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_shumaguan.png", 50, 40));
        this.appendValueInput("num1")
            .setCheck(Number)
            .setAlign(Blockly.ALIGN_RIGHT)
            .appendField(Blockly.MIXLY_KS_L);
        this.appendValueInput('BOOL')
            .setCheck([Number,Boolean])
            .appendField(Blockly.MIXLY_KS_MH);
        this.appendValueInput("num2")
            .setCheck(Number)
            .setAlign(Blockly.ALIGN_RIGHT)
            .appendField(Blockly.MIXLY_KS_R);
   
        this.setInputsInline(true);
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setTooltip('');
    }
};

/////////////////////8*8点阵/////////////////////

Blockly.Blocks.ks_matrix_init = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE)
    this.appendDummyInput("").appendField(Blockly.MIXLY_DISPLAY_MATRIX_INIT).appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_matrix.png", 70, 32));
    this.appendDummyInput("").setAlign(Blockly.ALIGN_RIGHT).appendField(new Blockly.FieldTextInput('myMatrix'), 'matrixName');
    this.appendValueInput("address", Number)
    .setCheck(Number)
    .setAlign(Blockly.ALIGN_RIGHT)
    .appendField("address:");
    this.appendValueInput("PIN1").setCheck(Number).setAlign(Blockly.ALIGN_RIGHT).appendField("SDA#");
    this.appendValueInput("PIN2").setCheck(Number).setAlign(Blockly.ALIGN_RIGHT).appendField("SCL#"); 
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
//   this.setTooltip("display_点阵屏初始化");
   }
};

//执行器_点阵屏显示_显示图案
Blockly.Blocks.ks_matrix1 = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("").appendField(new Blockly.FieldTextInput('myMatrix'), 'matrixName').appendField(Blockly.MIXLY_DISPLAY_MATRIX_SHOW).appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_matrix.png", 70, 32));
    this.appendValueInput("LEDArray").setAlign(Blockly.ALIGN_RIGHT).appendField(Blockly.MIXLY_DISPLAY_MATRIX_PICARRAY);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    //this.setTooltip();
  }
};
//执行器_点阵屏显示_图案数组
Blockly.Blocks.ks_matrix2 = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("").appendField(Blockly.MIXLY_DISPLAY_MATRIX_ARRAYVAR).appendField(new Blockly.FieldTextInput("LedArray1"), "VAR");
    this.appendDummyInput("").appendField(new Blockly.FieldCheckbox("FALSE"), "a81").appendField(new Blockly.FieldCheckbox("FALSE"), "a82").appendField(new Blockly.FieldCheckbox("FALSE"), "a83").appendField(new Blockly.FieldCheckbox("FALSE"), "a84").appendField(new Blockly.FieldCheckbox("FALSE"), "a85").appendField(new Blockly.FieldCheckbox("FALSE"), "a86").appendField(new Blockly.FieldCheckbox("FALSE"), "a87").appendField(new Blockly.FieldCheckbox("FALSE"), "a88");
    this.appendDummyInput("").appendField(new Blockly.FieldCheckbox("FALSE"), "a71").appendField(new Blockly.FieldCheckbox("FALSE"), "a72").appendField(new Blockly.FieldCheckbox("FALSE"), "a73").appendField(new Blockly.FieldCheckbox("FALSE"), "a74").appendField(new Blockly.FieldCheckbox("FALSE"), "a75").appendField(new Blockly.FieldCheckbox("FALSE"), "a76").appendField(new Blockly.FieldCheckbox("FALSE"), "a77").appendField(new Blockly.FieldCheckbox("FALSE"), "a78");
    this.appendDummyInput("").appendField(new Blockly.FieldCheckbox("FALSE"), "a61").appendField(new Blockly.FieldCheckbox("FALSE"), "a62").appendField(new Blockly.FieldCheckbox("FALSE"), "a63").appendField(new Blockly.FieldCheckbox("FALSE"), "a64").appendField(new Blockly.FieldCheckbox("FALSE"), "a65").appendField(new Blockly.FieldCheckbox("FALSE"), "a66").appendField(new Blockly.FieldCheckbox("FALSE"), "a67").appendField(new Blockly.FieldCheckbox("FALSE"), "a68");
    this.appendDummyInput("").appendField(new Blockly.FieldCheckbox("FALSE"), "a51").appendField(new Blockly.FieldCheckbox("FALSE"), "a52").appendField(new Blockly.FieldCheckbox("FALSE"), "a53").appendField(new Blockly.FieldCheckbox("FALSE"), "a54").appendField(new Blockly.FieldCheckbox("FALSE"), "a55").appendField(new Blockly.FieldCheckbox("FALSE"), "a56").appendField(new Blockly.FieldCheckbox("FALSE"), "a57").appendField(new Blockly.FieldCheckbox("FALSE"), "a58");
    this.appendDummyInput("").appendField(new Blockly.FieldCheckbox("FALSE"), "a41").appendField(new Blockly.FieldCheckbox("FALSE"), "a42").appendField(new Blockly.FieldCheckbox("FALSE"), "a43").appendField(new Blockly.FieldCheckbox("FALSE"), "a44").appendField(new Blockly.FieldCheckbox("FALSE"), "a45").appendField(new Blockly.FieldCheckbox("FALSE"), "a46").appendField(new Blockly.FieldCheckbox("FALSE"), "a47").appendField(new Blockly.FieldCheckbox("FALSE"), "a48");
    this.appendDummyInput("").appendField(new Blockly.FieldCheckbox("FALSE"), "a31").appendField(new Blockly.FieldCheckbox("FALSE"), "a32").appendField(new Blockly.FieldCheckbox("FALSE"), "a33").appendField(new Blockly.FieldCheckbox("FALSE"), "a34").appendField(new Blockly.FieldCheckbox("FALSE"), "a35").appendField(new Blockly.FieldCheckbox("FALSE"), "a36").appendField(new Blockly.FieldCheckbox("FALSE"), "a37").appendField(new Blockly.FieldCheckbox("FALSE"), "a38");
    this.appendDummyInput("").appendField(new Blockly.FieldCheckbox("FALSE"), "a21").appendField(new Blockly.FieldCheckbox("FALSE"), "a22").appendField(new Blockly.FieldCheckbox("FALSE"), "a23").appendField(new Blockly.FieldCheckbox("FALSE"), "a24").appendField(new Blockly.FieldCheckbox("FALSE"), "a25").appendField(new Blockly.FieldCheckbox("FALSE"), "a26").appendField(new Blockly.FieldCheckbox("FALSE"), "a27").appendField(new Blockly.FieldCheckbox("FALSE"), "a28");
    this.appendDummyInput("").appendField(new Blockly.FieldCheckbox("FALSE"), "a11").appendField(new Blockly.FieldCheckbox("FALSE"), "a12").appendField(new Blockly.FieldCheckbox("FALSE"), "a13").appendField(new Blockly.FieldCheckbox("FALSE"), "a14").appendField(new Blockly.FieldCheckbox("FALSE"), "a15").appendField(new Blockly.FieldCheckbox("FALSE"), "a16").appendField(new Blockly.FieldCheckbox("FALSE"), "a17").appendField(new Blockly.FieldCheckbox("FALSE"), "a18");
    this.setOutput(true, Number);
    //this.setTooltip();
  }
};

//执行器_点阵屏显示_清除屏幕
Blockly.Blocks.ks_Matrix_CLEAR = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("").appendField(new Blockly.FieldTextInput('myMatrix'), 'matrixName').appendField(Blockly.MIXLY_DISPLAY_MATRIX_SHOW);
    this.appendDummyInput("").setAlign(Blockly.ALIGN_RIGHT).appendField(Blockly.MIXLY_DISPLAY_MATRIX_CLEAR);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    //this.setTooltip();
  }
};
///////////////////LCD1602清屏///////////////////////
Blockly.Blocks.group_lcd_power = {
  init: function() {
    this.setColour(Blockly.Blocks.display.HUE);
    this.appendDummyInput()
        .appendField(Blockly.MIXLY_DF_LCD)
        .appendField(new Blockly.FieldTextInput('mylcd'), 'VAR')
        .appendField(new Blockly.FieldDropdown([[Blockly.MIXLY_LCD_STAT_ON, "display"], [Blockly.MIXLY_LCD_STAT_OFF, "noDisplay"], [Blockly.MIXLY_LCD_STAT_CURSOR, "cursor"], [Blockly.MIXLY_LCD_STAT_NOCURSOR, "noCursor"], [Blockly.MIXLY_LCD_STAT_BLINK, "blink"], [Blockly.MIXLY_LCD_STAT_NOBLINK, "noBlink"], [Blockly.MIXLY_LCD_STAT_CLEAR, "clear"], [Blockly.MIXLY_LCD_NOBACKLIGHT, "noBacklight"], [Blockly.MIXLY_LCD_BACKLIGHT, "backlight"]]), "STAT");
    this.appendValueInput('BOOL')
        .setCheck([Number,Boolean])
        .appendField(Blockly.MIXLY_KS_XY);
    this.setInputsInline(true);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
  }
};

///////////////////1602LCD//////////////////////
Blockly.Blocks.ks_1602lcd = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_KS_1602LCD)
    .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_lcd1602.png", 70, 32));

   // this.appendDummyInput("")
    //.appendField(Blockly.MIXLY_KS_clear)
   // .appendField(new Blockly.FieldDropdown([[Blockly.KS_ON, "HIGH"], [Blockly.KS_OFF, "LOW"]]), "STAT");
    this.appendValueInput("TEXT1", String)
    .setCheck([String,Number])
    .setAlign(Blockly.ALIGN_RIGHT)
    .appendField(Blockly.MIXLY_LCD_PRINT1);
    this.appendValueInput("TEXT2", String)
    .setCheck([String,Number])
    .setAlign(Blockly.ALIGN_RIGHT)
    .appendField(Blockly.MIXLY_LCD_PRINT2)
    
    //this.appendValueInput('BOOL')
    //.setCheck([Number,Boolean])
    //.appendField("            是否清屏：");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
  }
};

///////////////////LCD1602清屏///////////////////////
Blockly.Blocks.ks_1602lcd_clear = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField("1602LCD_clear")
    //.appendField(new Blockly.FieldDropdown([[Blockly.KS_ON, "HIGH"], [Blockly.KS_OFF, "LOW"]]), "STAT");
    this.setInputsInline(true);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
  }
};


/////////////////2004LCD//////////////////////
Blockly.Blocks.ks_2004lcd = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_KS_2004LCD)
    .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_lcd2004.png", 70, 32));

    this.appendValueInput("TEXT1", String)
    .setCheck([String,Number])
    .setAlign(Blockly.ALIGN_RIGHT)
    .appendField(Blockly.MIXLY_KS_one);
    this.appendValueInput("TEXT2", String)
    .setCheck([String,Number])
    .setAlign(Blockly.ALIGN_RIGHT)
    .appendField(Blockly.MIXLY_KS_two)
    this.appendValueInput("TEXT3", String)
    .setCheck([String,Number])
    .setAlign(Blockly.ALIGN_RIGHT)
    .appendField(Blockly.MIXLY_KS_three);
    this.appendValueInput("TEXT4", String)
    .setCheck([String,Number])
    .setAlign(Blockly.ALIGN_RIGHT)
    .appendField(Blockly.MIXLY_KS_four)
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
  }
};

///////////////////LCD1602清屏///////////////////////
Blockly.Blocks.ks_2004lcd_clear = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField("2004LCD_clear")
    //.appendField(new Blockly.FieldDropdown([[Blockly.KS_ON, "HIGH"], [Blockly.KS_OFF, "LOW"]]), "STAT");
    this.setInputsInline(true);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
  }
};


////////////////////OLED////////////////////////
Blockly.Blocks.ks_oled = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_KS_OLED)
    .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_oled.png", 70, 32));

    this.appendValueInput("size", Number)
    .setCheck(Number)
    .setAlign(Blockly.ALIGN_RIGHT)
    .appendField("SIZE");
 
    this.appendValueInput("TEXT1", String)
    .setCheck([String,Number])
    .setAlign(Blockly.ALIGN_RIGHT)
    .appendField(Blockly.MIXLY_KS_one);
    this.appendValueInput("TEXT2", String)
    .setCheck([String,Number])
    .setAlign(Blockly.ALIGN_RIGHT)
    .appendField(Blockly.MIXLY_KS_two);
    this.appendValueInput("TEXT3", String)
    .setCheck([String,Number])
    .setAlign(Blockly.ALIGN_RIGHT)
    .appendField(Blockly.MIXLY_KS_three);
    this.appendValueInput("TEXT4", String)
    .setCheck([String,Number])
    .setAlign(Blockly.ALIGN_RIGHT)
    .appendField(Blockly.MIXLY_KS_four);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
  }
};

///////////////////OLED清屏///////////////////////
Blockly.Blocks.ks_oled_clear = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField("OLED_clear")
    //.appendField(new Blockly.FieldDropdown([[Blockly.KS_ON, "HIGH"], [Blockly.KS_OFF, "LOW"]]), "STAT");
    this.setInputsInline(true);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
  }
};


/////////////////////////////通讯/////////////////////////////////////////////

////////////////红外接收////////////////////////////
//红外接收模块
Blockly.Blocks.ks_ir_r = {
    init: function () {
        this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
        this.appendValueInput("PIN", Number)
            .appendField(new Blockly.FieldTextInput('ir_rec'), 'VAR')
            .appendField(Blockly.MIXLY_KS_IR_R)
            .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_irr.png", 70, 32))
            .setCheck(Number);
        this.appendStatementInput('DO')
            .appendField(Blockly.MIXLY_KS_rec);
        this.setPreviousStatement(true);
        this.setNextStatement(true);
        this.setInputsInline(true);
        this.setTooltip(Blockly.MIXLY_IR_RECIEVE_TOOLTIP);
    },
    getVars: function () {
        return [this.getFieldValue('VAR')];
    },
    renameVar: function (oldName, newName) {
        if (Blockly.Names.equals(oldName, this.getFieldValue('VAR'))) {
            this.setTitleValue(newName, 'VAR');
        }
    }
};

////////////////////红外发射/////////////////////
Blockly.Blocks.ks_ir_s = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField(Blockly.MIXLY_KS_IR_E)
    .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_irs.png", 43, 32));
    
    this.appendValueInput("num1", Number)
    .setCheck(Number)
    .setAlign(Blockly.ALIGN_RIGHT)
    .appendField("Send");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
  }
};

//////////////////////蓝牙////////////////////////////
Blockly.Blocks.ks_bluetooth = {
    init: function () {
        this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
        this.appendValueInput("PIN1", Number)
            .appendField(new Blockly.FieldTextInput('val'), 'VAL')
            .appendField(Blockly.MIXLY_KS_BLUETOOTH)
            .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_bluetooth.png", 70, 32))
            .appendField("RX:")
            .setCheck(Number);
        this.appendValueInput("PIN2", Number)
            .appendField("TX:")
            .setCheck(Number);
        this.appendStatementInput('DO')
            .appendField(Blockly.MIXLY_KS_rec);
        this.setPreviousStatement(true);
        this.setNextStatement(true);
        this.setInputsInline(true);
        this.setTooltip("bluetooth");
    },
    getVars: function () {
        return [this.getFieldValue('VAL')];
    },
    renameVar: function (oldName, newName) {
        if (Blockly.Names.equals(oldName, this.getFieldValue('VAL'))) {
            this.setTitleValue(newName, 'VAL');
        }
    }
};


///////////////////esp8266//////////////////////
Blockly.Blocks.ks_esp8266 = {
  init: function() {
    this.setColour(Blockly.Blocks.KS_EasyPulg.HUE);
    this.appendDummyInput("")
    .appendField("ESP8266")
    .appendField(new Blockly.FieldImage("../../media/KS_EasyPulg/ks_esp8266.png", 70, 32));

    //this.appendDummyInput("")
   // .appendField(Blockly.MIXLY_KS_clear)
   // .appendField(new Blockly.FieldDropdown([[Blockly.KS_ON, "HIGH"], [Blockly.KS_OFF, "LOW"]]), "STAT");
    this.appendValueInput("TEXT1", String)
    .setCheck([String,Number])
    .setAlign(Blockly.ALIGN_RIGHT)
    .appendField("SSID:");
    this.appendValueInput("TEXT2", String)
    .setCheck([String,Number])
    .setAlign(Blockly.ALIGN_RIGHT)
    .appendField("passward:")
    
    //this.appendValueInput('BOOL')
    //.setCheck([Number,Boolean])
    //.appendField("            是否清屏：");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
  }
};